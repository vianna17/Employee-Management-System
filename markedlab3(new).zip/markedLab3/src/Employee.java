public class Employee implements Comparable<Employee> {
    private String role; //This is a Java class named Employee that
                          // implements the Comparable interface.
    private String name;
    private double salary; //Employee class has three private instance variables:
                           // role (a String), name (a String), and salary (a double).

    public Employee(String role, String name, double salary) {
        this.role = role; //The constructor of the Employee class takes three arguments,
                           // which are used to set the values of the instance variables.
        this.name = name;
        this.salary = salary;
    }

    public String getRole() {
        return role;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public int compareTo(Employee other) { //The class implements the compareTo() method,
        // which is required by the Comparable interface.
        // Compare by salary first
        int salaryCmp = Double.compare(this.salary, other.salary);
        if (salaryCmp != 0) { //If the salaries are equal, the method compares the names of the two Employee
                              // objects using the compareTo() method of the String class.
            return salaryCmp;
        }  //
        // If salaries are equal, compare by name
        int nameCmp = this.name.compareTo(other.name);
        if (nameCmp != 0) {
            return nameCmp;
        }
        // If names are also equal, compare by role
        return this.role.compareTo(other.role);
    }
    @Override
    public String toString() {
        return this.role + " " + this.name + " " + this.salary;
    }
}

