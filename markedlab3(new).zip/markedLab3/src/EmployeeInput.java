import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class EmployeeInput {
    public static void main(String[] args) { //The code defines a main method that creates a
                                                  // Scanner object and an ArrayList to store Employee objects:
        Scanner scanner = new Scanner(System.in);
        ArrayList<Employee> employees = new ArrayList<>();

        while (true) { //The code uses a while loop to repeatedly prompt
                        // the user to enter employee details until the user enters "quit":
            System.out.print("Enter employee details (name role salary), or 'quit' to exit: ");
            String input = scanner.nextLine();
            if (input.equals("quit")) { // Detect if the user enters "quit"
                Collections.sort(employees); // Sort the list of employees
                System.out.println("Sorted list of employees:");
                for (Employee employee : employees) { //
                    System.out.println(employee);
                }
                break; // Exit the loop
            }
            String[] parts = input.split("\\s+"); //Inside the loop, the code splits the user input into an array of strings and
                                                         // checks that it has three elements (name, role, and salary):
            if (parts.length != 3) { // Detect if more or less than three values are entered
                System.out.println("Invalid input: please enter three values");
                continue;
            }
            String name = parts[0]; //The code extracts the name, role, and salary from the input
                                      // array and creates an Employee object using these values:
            String role = parts[1];
            double salary;
            try {
                salary = Double.parseDouble(parts[2]); // Detect if the user enters a non-numerical value for salary
            } catch (NumberFormatException e) {
                System.out.println("Invalid salary: " + parts[2]);
                continue;
            }
            Employee employee = new Employee(role, name, salary); //The code adds the Employee object to the ArrayList of employees and
                                                                        // prints a message confirming
                                                                     // that the employee was added:
            employees.add(employee);
            System.out.println("Added employee: " + employee);
        }
    }
}




