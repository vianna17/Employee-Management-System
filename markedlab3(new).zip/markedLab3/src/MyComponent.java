import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

public class MyComponent extends JComponent { // this program uses GUI. Component is implemented as
    // a subclass of the "JComponent" class and is called "MyComponent".

    private Map<Integer, Integer> quadrantCounts; // A map to store the number of times an event occurs in each quadrant

    public MyComponent() {
        quadrantCounts = new HashMap<>(); // "HashMap" to keep track of the number of times the user interacts
        quadrantCounts.put(1, 0);  // with each quadrant.
        quadrantCounts.put(2, 0); // Initialize the counts to zero for each quadrant
        quadrantCounts.put(3, 0);
        quadrantCounts.put(4, 0);

        addMouseListener(new MouseListener() { //
            @Override
            public void mouseClicked(MouseEvent e) {
                int quadrant = getQuadrant(e.getX(), e.getY());
                incrementCount(quadrant);
                printCounts();
            }
            @Override
            public void mouseEntered(MouseEvent e) {}
            @Override
            public void mouseExited(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
        });

        addKeyListener(new KeyListener() { //The addKeyListener() method adds another anonymous class that implements
                                           // the KeyListener interface.
            @Override
            public void keyPressed(KeyEvent e) {
                // Ignore key presses that don't produce a visible character
                if (e.getKeyChar() == KeyEvent.CHAR_UNDEFINED) {
                    return; //This class provides implementations for the keyPressed(),
                                // keyReleased(), and keyTyped() methods.
                }
                int quadrant = getQuadrant(getMousePosition().x, getMousePosition().y);
                incrementCount(quadrant);
                printCounts();
            }
            @Override
            public void keyReleased(KeyEvent e) {}
            @Override
            public void keyTyped(KeyEvent e) {}
        });

        setFocusable(true); //the setFocusable(true) method is
        // called to ensure that the component can receive input events.




    }

    private int getQuadrant(int x, int y) { // "getQuadrant" method takes x and y coordinates
        int width = getWidth(); // of a point the component and returns an integer indicating which quadrant
        int height = getHeight(); // the point is in.
        int halfWidth = width / 2;
        int halfHeight = height / 2;
        if (x < halfWidth && y < halfHeight) { // Quadrant 1
            return 1;
        } else if (x >= halfWidth && y < halfHeight) { // Quadrant 2
            return 2;
        } else if (x >= halfWidth && y >= halfHeight) { // Quadrant 3
            return 3;
        } else { // Quadrant 4
            return 4;
        }
    }

    private void incrementCount(int quadrant) { // increments the count for the specified quadrant
        int count = quadrantCounts.get(quadrant); // quadrant "quadrantCounts" map.
        quadrantCounts.put(quadrant, count + 1);
    }

    private void printCounts() { //The printCounts() method prints the
                                   // current counts for each quadrant in the quadrantCounts map.
        System.out.println("Quadrant counts:");
        for (int quadrant : quadrantCounts.keySet()) {
            int count = quadrantCounts.get(quadrant);
            System.out.println("Quadrant " + quadrant + ": " + count);
        }
        System.out.println();
    }

    public static void main(String[] args) { //The main() method creates a JFrame object,
        // sets its title, size, and visibility and creates a new MyComponent object.
        JFrame frame = new JFrame("My Component"); //It then adds the MyComponent object to the frame.
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setVisible(true);

        MyComponent myComponent = new MyComponent();
        frame.add(myComponent); //When the program is run, the MyComponent will be displayed in the JFrame.
    }
}
